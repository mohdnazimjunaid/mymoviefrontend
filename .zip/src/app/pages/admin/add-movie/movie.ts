export class Movie {
    movieId:number|any;
    movieName:String|any;
    theaterName:String|any;
    totalSeats:number|any;
}
