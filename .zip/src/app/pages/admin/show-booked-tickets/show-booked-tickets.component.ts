import { Component , Input, OnInit} from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { MovieserviceService } from 'src/app/services/movieservice.service';
import { Alltickets } from './alltickets';

@Component({
  selector: 'app-show-booked-tickets',
  templateUrl: './show-booked-tickets.component.html',
  styleUrls: ['./show-booked-tickets.component.css']
})
export class ShowBookedTicketsComponent implements OnInit{

  @Input("ELEMENT_DATA") ELEMENT_DATA!:Alltickets[]
  displayedColumns: string[] = [
    'transactionId',
   'movieName',
  'totalSeats',
'availableSeats',
'bookedSeats',
];
dataSource = new MatTableDataSource<Alltickets>(this.ELEMENT_DATA)

constructor(private _viewmovie:MovieserviceService)
{}

ngOnInit(): void{
  this.getAllReports();
  }

  public getAllReports()
  {
    let resp=this._viewmovie.alltickets();
    resp.subscribe(report=>this.dataSource.data=report as Alltickets[])
  }

}
