import { Alltickets } from './alltickets';

describe('Alltickets', () => {
  it('should create an instance', () => {
    expect(new Alltickets()).toBeTruthy();
  });
});
