import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from 'src/app/services/user.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-forgotpassword',
  templateUrl: './forgotpassword.component.html',
  styleUrls: ['./forgotpassword.component.css']
})
export class ForgotpasswordComponent {

  userName:any
  forgotData={
    securityQuestionAns:'',
    password:''
  }
    constructor(private user:UserService, private router:Router)
    {}
  
    passwordChange() {
      this.user.forgotPassword(this.forgotData, this.userName).subscribe(
        (response: any) => {
          console.log("Success");
          console.log(response);
          Swal.fire('Success', 'Password Updated Successfully !!', 'success');
          this.router.navigate(['/login']);
        },
        (error) => {
          console.log("Error");
          console.log(error);
          Swal.fire('Error', 'Error in Updating Password', 'error');
        }
      );
    }
    
    
  

}
