import { Component, Input , OnInit } from '@angular/core';
import { Allmovies } from '../../admin/allmovies';
import { MatTableDataSource } from '@angular/material/table';
import { MovieserviceService } from 'src/app/services/movieservice.service';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-show-movies',
  templateUrl: './show-movies.component.html',
  styleUrls: ['./show-movies.component.css']
})
export class ShowMoviesComponent implements OnInit {

  @Input("ELEMENT_DATA") ELEMENT_DATA!:Allmovies[]
  displayedColumns: string[] = [
    'movieId',
   'movieName',
 'theaterName',
'availableSeats',
'bookedTickets',
];
  dataSource = new MatTableDataSource<Allmovies>(this.ELEMENT_DATA)

  constructor(private _viewmovie:MovieserviceService, private _snack:MatSnackBar)
  {}
  ngOnInit(): void{
    // this._viewmovie.allmovies().subscribe((data:any)=>
    // {
    //   this.movies=data;
    //   console.log(this.movies);
    // }
    // ,
    // (error)=>{
    //   console.log(error);
    // }
    // )
this.getAllReports();

  }

  public getAllReports()
  {
    let resp=this._viewmovie.allmovies();
    resp.subscribe(report=>this.dataSource.data=report as Allmovies[])
  }

  public addTicket(mid:any){
    alert(mid);
  }

}
