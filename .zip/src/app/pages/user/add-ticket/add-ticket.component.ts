import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { TicketService } from 'src/app/services/ticket.service';
import Swal from 'sweetalert2';
import { Addticket } from './addticket';

@Component({
  selector: 'app-add-ticket',
  templateUrl: './add-ticket.component.html',
  styleUrls: ['./add-ticket.component.css']
})
export class AddTicketComponent implements OnInit {

  mid: any;
  mname:any

  ticketObj:Addticket=new Addticket()

  constructor(private _route:ActivatedRoute, private service:TicketService)
  {}

ngOnInit() :void{
  this.mid=this._route.snapshot.params['mid'];
  this.mname=this._route.snapshot.params['mname']
 // console.log(this.mid)
 this.ticketObj.movie_id_fk=this.mid
 this.ticketObj.movieName=this.mname
}

addTicket() {
  if (this.ticketObj.bookedSeats == null) {
    return;
  }

  this.service.addTicket(this.ticketObj, this.mid).subscribe(
    (data:any) => {
    //  console.log("YOUR DATA");
    //  console.log(data);
  
      if (data.Message === "Added") {
        console.log("ADDED");
        Swal.fire('success', 'Ticket added', 'success');
      } else if (data.Message === "Sold") {
        console.log("SOLD");
        Swal.fire('error', 'Sorry all Tickets are already sold Search for other Movies', 'error');
      } else {
        console.log("UNKNOWN RESPONSE");
        Swal.fire('error', 'Error in adding ticket', 'error');
      }
    },
    (error) => {
      console.log("ERROR");
      Swal.fire('error', 'Error in adding ticket', 'error');
      console.log(error);
    }
  );
  }  


}

