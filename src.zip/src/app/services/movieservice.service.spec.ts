// import { TestBed, inject } from '@angular/core/testing';
// import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
// import { MovieserviceService } from './movieservice.service';
// import { HttpClient, HttpClientModule } from '@angular/common/http';
// import { AddMovieComponent } from '../pages/admin/add-movie/add-movie.component';
// import { Movie } from '../pages/admin/add-movie/movie';
// export const baseUrl = 'http://localhost:8081/api/v1'; 

// fdescribe('MovieserviceService', () => {
//   let movieservice: MovieserviceService;
//   let addmoviecomp : AddMovieComponent
//   let movie:Movie
//   let httpMock: HttpTestingController;

//   beforeEach(() => {
//     TestBed.configureTestingModule({
//       imports: [HttpClientTestingModule,HttpClientModule],
//       providers: [MovieserviceService,AddMovieComponent]
//     });
//     movieservice = TestBed.inject(MovieserviceService);
//     addmoviecomp= TestBed.inject(AddMovieComponent)
//     httpMock = TestBed.inject(HttpTestingController);
//   });

//   afterEach(() => {
//     httpMock.verify();
//   });

//   it('should add a movie', () => {
//      movie = {
//       movieId: '1',
//       movieName: 'Avengers',
//       theaterName: 'Pacific',
//       totalSeats: '100'
//     };

//     movieservice.addMovie(movie).subscribe((data) => {
//       expect(data).toBeTruthy();
//       expect(data.movieId).toBe('1');
//       expect(data.movieName).toBe('Avengers');
//       expect(data.theaterName).toBe('Pacific');
//       expect(data.totalSeats).toBe('100');
//     });

//     const req = httpMock.expectOne(`${'baseUrl'}/addmovie`);
//     expect(req.request.method).toBe('POST');
//     req.flush(movie);
//   });
//   it('should get all movies', () => {
//     const mockMovies = [
//       {
//         movieId: '1',
//         movieName: 'Avengers',
//         theaterName: 'Pacific',
//         totalSeats: '100',
//       },
//       {
//         movieId: '2',
//         movieName: 'Fast X',
//         theaterName: 'Pacific',
//         totalSeats: '200',
//       }
//     ];

//     movieservice.allmovies().subscribe((movies) => {
//       expect(movies).toEqual(mockMovies);
//     });

//     const req = httpMock.expectOne(`${'baseUrl'}/getAllMovies`);
//     expect(req.request.method).toBe('GET');
//     req.flush(mockMovies);
//   });
// });