export class Alltickets {
    transactionId:number|any;
    movieName:String|any;
    totalSeats:number|any;
    availableSeats:number|any
    bookedSeats: number|any
}
