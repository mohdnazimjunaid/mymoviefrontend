// import { Allmovies } from './allmovies';

// describe('Allmovies', () => {
//   it('should create an instance', () => {
//     expect(new Allmovies()).toBeTruthy();
//   });
// });
