export class Addticket {
    movie_id_fk:number|any;
    movieName:String|any;
    theaterName:String|any;
    bookedSeats:number|any;
}
