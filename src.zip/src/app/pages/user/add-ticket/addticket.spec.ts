import { Addticket } from './addticket';

describe('Addticket', () => {
  it('should create an instance', () => {
    expect(new Addticket()).toBeTruthy();
  });
});
